# Simplified Trading Bot — Binance Futures Testnet (USDT-M)

A small CLI application that places MARKET, LIMIT, and (bonus) STOP_LIMIT orders
on Binance Futures Testnet, with input validation, structured error handling,
and request/response logging.

## Project structure

```
trading_bot/
  bot/
    __init__.py
    client.py         # Talks to Binance (the only network-facing module)
    orders.py          # Builds/validates OrderRequest objects, places orders
    validators.py       # Pure input-validation functions
    logging_config.py    # Rotating file + console logger
  cli.py                # argparse CLI entry point
  requirements.txt
  .env.example
  example_logs/
    example_trading_bot.log   # Sample log output (see note below)
  README.md
```

## Setup

> **Note on Binance's testnet migration:** Binance retired the old standalone
> Futures Testnet (`testnet.binancefuture.com` with its own separate,
> GitHub-login account) in favor of **"Demo Trading"**, which now lives
> inside your regular Binance.com account. Visiting the old testnet URL
> today redirects into your real account. This project targets the current
> Demo Trading environment (`demo-api.binance.com` / `demo-fapi.binance.com`)
> via `python-binance`'s `demo=True` flag.

1. **Enable Demo Trading on your Binance account:**
   - Log in to https://www.binance.com with your normal account.
   - Navigate to **Futures → Demo Trading** (or visit the Demo Trading page
     directly) and click **"Start demo trading"**. This activates a demo
     sub-environment with virtual USDT funded automatically — it does not
     touch your real balance.
   - Generate an API key scoped for Demo Trading from **Account → API
     Management**. If your account normally requires KYC/identity
     verification to reach API Management, that's a real-account
     requirement, not something specific to demo trading — you'll need to
     complete it once to unlock API key creation.

2. **Clone/unzip this project**, then install dependencies:

   ```bash
   cd trading_bot
   pip install -r requirements.txt
   ```

3. **Configure credentials.** Copy `.env.example` to `.env` and fill in your
   testnet API key/secret:

   ```bash
   cp .env.example .env
   ```

   ```
   BINANCE_API_KEY=your_testnet_api_key_here
   BINANCE_API_SECRET=your_testnet_api_secret_here
   ```

   (Alternatively, export these as real environment variables instead of
   using a `.env` file.)

## Running it

```bash
# Market order
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

# Limit order
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 61000

# Bonus: Stop-Limit order
python cli.py --symbol BTCUSDT --side SELL --type STOP_LIMIT --quantity 0.01 --price 58000 --stop-price 58500
```

Each run prints:
- the validated order request summary,
- the raw order response (order ID, status, executed quantity, average price when available),
- a clear success/failure message.

All requests, responses, and errors are also written to `logs/trading_bot.log`
(created automatically on first run, rotated at 2MB).

## CLI arguments

| Flag           | Required        | Notes                                   |
|----------------|------------------|------------------------------------------|
| `--symbol`     | yes              | e.g. `BTCUSDT`                           |
| `--side`       | yes              | `BUY` or `SELL`                          |
| `--type`       | yes              | `MARKET`, `LIMIT`, or `STOP_LIMIT`       |
| `--quantity`   | yes              | must be > 0                              |
| `--price`      | LIMIT/STOP_LIMIT | required for those two order types       |
| `--stop-price` | STOP_LIMIT       | required only for STOP_LIMIT             |

Invalid input (bad symbol format, unsupported side/type, missing price,
non-positive quantity, etc.) is rejected before any network call is made,
with a specific error message and an entry in the log file.

## Error handling

- **Input validation errors** (`bot/validators.py`) are caught in `cli.py`
  and reported without ever touching the network.
- **Binance API errors** (e.g. invalid symbol, LOT_SIZE filter failures,
  insufficient testnet balance) are caught in `bot/client.py`, logged with
  the full exception, and re-raised so the CLI can print a clean
  `[FAILED]` message.
- **Network/connectivity errors** (timeouts, DNS failures, etc.) are caught
  the same way as API errors, since both are just "the order didn't go
  through" from the user's perspective.

## Design notes / assumptions

- Uses the `python-binance` library with `Client(api_key, api_secret, demo=True)`,
  which points futures endpoints at Binance's current Demo Trading hosts
  (`demo-api.binance.com` / `demo-fapi.binance.com`) rather than the
  deprecated standalone testnet — no manual URL wiring needed. If your
  installed `python-binance` version predates this flag, upgrade it
  (`pip install -U python-binance`) rather than falling back to `testnet=True`,
  which now points at a stale host.
- STOP_LIMIT is implemented as Binance Futures' `STOP` order type (price +
  stopPrice), chosen as the bonus feature over OCO/TWAP/Grid for simplicity
  and because it maps directly onto the existing LIMIT code path.
- `timeInForce` defaults to `GTC` for LIMIT/STOP_LIMIT orders since the task
  didn't specify one.
- Quantities/prices are taken as-is from the CLI (as floats); this project
  does not attempt to auto-round to each symbol's exchange filter precision
  — if you hit a `LOT_SIZE` or `PRICE_FILTER` error, adjust the quantity/price
  to match the symbol's step size on the testnet.
- The client class only ever talks to the Futures Testnet base URL; it is
  not configured to accidentally hit the live Binance API.

## About `example_logs/`

`example_logs/example_trading_bot.log` shows what the log output looks like
for a MARKET order, a LIMIT order, and a rejected order — generated with a
mocked API client so this repo doesn't ship real testnet order data. **When
you run the bot yourself against your own testnet account**, a real
`logs/trading_bot.log` will be created there instead — that's the file to
include as your submission evidence of one MARKET and one LIMIT order.

## Possible future improvements

- Query `exchangeInfo` to auto-validate/round quantity and price against
  each symbol's LOT_SIZE and PRICE_FILTER before submitting.
- Add `--dry-run` to print the constructed order without sending it.
- Add unit tests for `bot/validators.py` and `bot/orders.py` (both are pure
  functions with no network dependency, so they're easy to test in isolation).
