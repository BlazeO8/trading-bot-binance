"""Thin wrapper around python-binance's Client, scoped to Futures Demo Trading.

This is the only module that talks to the network. Keeping it isolated
means the CLI and order-building logic can be unit-tested by mocking
this class, and it's the single place that needs to change if the
underlying HTTP library or API version ever changes.

Binance retired the old standalone Futures Testnet (testnet.binancefuture.com
with its own GitHub-based login) in favor of "Demo Trading", which now lives
inside a regular Binance account and talks to demo-api.binance.com /
demo-fapi.binance.com. Recent versions of python-binance (>=1.0.29-ish)
support this natively via demo=True.
"""
import os

from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceRequestException

from .logging_config import get_logger

logger = get_logger(__name__)


class BinanceFuturesTestnetClient:
    """Wraps python-binance's Client for USDT-M Futures Demo Trading order placement.

    Named "Testnet" for continuity with the task brief, but under the hood
    this now targets Binance's current Demo Trading environment (see module
    docstring) rather than the deprecated testnet.binancefuture.com host.
    """

    def __init__(self, api_key: str = None, api_secret: str = None):
        api_key = api_key or os.getenv("BINANCE_API_KEY")
        api_secret = api_secret or os.getenv("BINANCE_API_SECRET")

        if not api_key or not api_secret:
            raise RuntimeError(
                "Missing API credentials. Set BINANCE_API_KEY and BINANCE_API_SECRET "
                "as environment variables (or in a .env file) before running the bot."
            )

        # Binance retired the old standalone Futures Testnet (testnet.binancefuture.com,
        # GitHub login) in favor of "Demo Trading", which lives inside a regular
        # Binance account. Recent python-binance versions (>=1.0.29 or so) support this
        # natively via demo=True, which routes futures calls to demo-fapi.binance.com.
        self._client = Client(api_key, api_secret, demo=True)
        logger.info(
            "Initialized Binance Futures Demo Trading client (%s).",
            self._client.FUTURES_DEMO_URL,
        )

    def create_order(self, **params) -> dict:
        """Send an order to Binance Futures Testnet and return the raw response."""
        logger.info("Sending order request: %s", params)
        try:
            response = self._client.futures_create_order(**params)
            logger.info("Order response: %s", response)
            return response
        except (BinanceAPIException, BinanceRequestException) as exc:
            logger.error("Binance API error while placing order: %s", exc)
            raise
        except Exception as exc:  # network errors, timeouts, DNS failures, etc.
            logger.error("Unexpected/network error while placing order: %s", exc)
            raise

    def get_symbol_price(self, symbol: str) -> float:
        """Convenience helper, useful for sanity-checking LIMIT prices."""
        try:
            ticker = self._client.futures_symbol_ticker(symbol=symbol)
            price = float(ticker["price"])
            logger.info("Fetched mark price for %s: %s", symbol, price)
            return price
        except (BinanceAPIException, BinanceRequestException) as exc:
            logger.error("Failed to fetch price for %s: %s", symbol, exc)
            raise
