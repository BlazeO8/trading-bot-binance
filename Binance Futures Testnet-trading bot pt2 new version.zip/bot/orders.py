"""Order construction and placement logic, decoupled from the CLI layer."""
from dataclasses import dataclass
from typing import Optional

from . import validators
from .client import BinanceFuturesTestnetClient
from .logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class OrderRequest:
    """A validated, ready-to-submit order."""

    symbol: str
    side: str
    order_type: str
    quantity: float
    price: Optional[float] = None
    stop_price: Optional[float] = None

    @classmethod
    def build(cls, symbol, side, order_type, quantity, price=None, stop_price=None):
        """Validate raw CLI input and return a clean OrderRequest.

        Raises validators.ValidationError on any bad input.
        """
        order_type = validators.validate_order_type(order_type)
        symbol = validators.validate_symbol(symbol)
        side = validators.validate_side(side)
        quantity = validators.validate_quantity(quantity)
        price = validators.validate_price(price, order_type)
        stop_price = validators.validate_stop_price(stop_price, order_type)
        return cls(symbol, side, order_type, quantity, price, stop_price)

    def to_binance_params(self) -> dict:
        """Translate this request into futures_create_order() kwargs."""
        params = {
            "symbol": self.symbol,
            "side": self.side,
            "quantity": self.quantity,
        }
        if self.order_type == "MARKET":
            params["type"] = "MARKET"
        elif self.order_type == "LIMIT":
            params.update({"type": "LIMIT", "price": self.price, "timeInForce": "GTC"})
        elif self.order_type == "STOP_LIMIT":
            # Binance Futures calls this order type "STOP" (as opposed to "STOP_MARKET").
            params.update(
                {
                    "type": "STOP",
                    "price": self.price,
                    "stopPrice": self.stop_price,
                    "timeInForce": "GTC",
                }
            )
        return params

    def summary(self) -> str:
        parts = [
            f"symbol={self.symbol}",
            f"side={self.side}",
            f"type={self.order_type}",
            f"quantity={self.quantity}",
        ]
        if self.price is not None:
            parts.append(f"price={self.price}")
        if self.stop_price is not None:
            parts.append(f"stop_price={self.stop_price}")
        return ", ".join(parts)


class OrderService:
    """High-level API for placing orders and formatting results for display."""

    def __init__(self, client: Optional[BinanceFuturesTestnetClient] = None):
        self.client = client or BinanceFuturesTestnetClient()

    def place_order(self, order: OrderRequest) -> dict:
        logger.info("Placing order -> %s", order.summary())
        params = order.to_binance_params()
        return self.client.create_order(**params)

    @staticmethod
    def format_response(response: dict) -> str:
        """Format an order response for display.

        Binance Futures Demo/Testnet places MARKET and LIMIT orders through
        the regular order endpoint (response has orderId/status/executedQty),
        but routes STOP orders through the conditional/algo-order system
        instead (response has algoId/algoStatus/triggerPrice, and no
        orderId/status/executedQty at all, since a STOP order hasn't
        executed yet -- it's just resting on the book waiting to trigger).

        Reading orderId/status/executedQty off an algo-order response is
        what produced the "Order ID: None / Status: None" bug, so we detect
        which shape we got and format each one with its own real fields.
        """
        if "algoId" in response:
            return OrderService._format_algo_response(response)
        return OrderService._format_regular_response(response)

    @staticmethod
    def _format_regular_response(response: dict) -> str:
        """Format a regular (MARKET/LIMIT) order response."""
        lines = [
            f"Order ID       : {response.get('orderId')}",
            f"Status         : {response.get('status')}",
            f"Executed Qty   : {response.get('executedQty')}",
        ]
        avg_price = response.get("avgPrice")
        if avg_price is not None and float(avg_price) > 0:
            lines.append(f"Avg Price      : {avg_price}")
        return "\n".join(lines)

    @staticmethod
    def _format_algo_response(response: dict) -> str:
        """Format a conditional/algo (STOP) order response.

        These orders are accepted and resting on Binance's books, but have
        not executed yet -- they only fill once the market reaches
        triggerPrice. That's why there's no executedQty/avgPrice to show:
        there isn't one until (and unless) the order actually triggers.
        """
        lines = [
            f"Algo Order ID  : {response.get('algoId')}",
            f"Algo Status    : {response.get('algoStatus')}",
            f"Order Type     : {response.get('orderType')}",
            f"Trigger Price  : {response.get('triggerPrice')}",
        ]
        price = response.get("price")
        if price is not None:
            lines.append(f"Limit Price    : {price}")
        lines.append(
            "Note           : Conditional order resting on the book; it "
            "will only execute once the trigger price is reached."
        )
        return "\n".join(lines)
