"""Simplified Trading Bot package for Binance Futures Testnet (USDT-M)."""
